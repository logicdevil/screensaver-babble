/**
 * Created by daymond on 12/16/16.
 */
public class Screensaver {


    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow();
        mainWindow.start();
    }
}
