import javax.swing.*;
import java.awt.*;

/**
 * Created by daymond on 12/17/16.
 */
public class DCanvas extends JPanel {


    @Override
    public void paint(Graphics graphics) {
        super.paint(graphics);
        graphics.drawImage(MainWindow.IMAGE, 0, 0, null);

    }
}
