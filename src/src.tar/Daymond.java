import java.awt.*;

/**
 * Created by daymond on 12/17/16.
 */
public class Daymond {

    Image image;
    int x;
    int y;

    public Daymond(Image image, int x, int y){
        this.image = image;
    }
    public void paint(Graphics graphics) {
        graphics.drawImage(image, x, y, null);
    }
}
