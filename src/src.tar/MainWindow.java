import javax.swing.*;
import java.awt.*;

/**
 * Created by daymond on 12/16/16.
 */
public class MainWindow {


    JFrame frame;
    DCanvas canvas;

    public static Image IMAGE = ScreenCreater.createScreen();

    public void start(){
        frame = new JFrame();
        frame.setTitle("Title");
        frame.setResizable(false);
        if(!frame.isDisplayable()) {
            frame.setUndecorated(true);
        }

        GraphicsDevice graphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();

        try {
            graphicsDevice.setFullScreenWindow(frame);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        canvas = new DCanvas();
        canvas.setBackground(Color.white);
        frame.getContentPane().add(BorderLayout.CENTER, canvas);

        frame.setVisible(true);
        try {
            Thread.sleep(10000);
        } catch (Exception e){}
        System.exit(0);


    }
}
